/*
  Grand Palace Hotel website
  IMPORTANT: Replace WHATSAPP_NUMBER with the hotel's WhatsApp number.
  Use country code + number, digits only; for India, for example: 919876543210.
*/
const WHATSAPP_NUMBER = "910000000000"; // Replace this demo number before launch.

const whatsappUrl = (message) =>
  `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;

const isPlaceholderNumber = () =>
  !WHATSAPP_NUMBER || WHATSAPP_NUMBER === "910000000000" || WHATSAPP_NUMBER.length < 10;

function openWhatsApp(message) {
  if (isPlaceholderNumber()) {
    showToast("Please add the hotel's real WhatsApp number in script.js first.");
    return;
  }
  window.open(whatsappUrl(message), "_blank", "noopener,noreferrer");
}

function showToast(message) {
  const toast = document.getElementById("toast");
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add("show");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove("show"), 3500);
}

document.addEventListener("DOMContentLoaded", () => {
  const menuToggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".main-nav");

  menuToggle?.addEventListener("click", () => {
    const isOpen = nav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  });

  document.querySelectorAll(".main-nav a").forEach(link => {
    link.addEventListener("click", () => {
      nav.classList.remove("open");
      menuToggle?.setAttribute("aria-expanded", "false");
    });
  });

  // Use local date strings to avoid timezone shifting the minimum date.
  const today = new Date();
  const localDate = new Date(today.getTime() - today.getTimezoneOffset() * 60000)
    .toISOString().slice(0, 10);
  const checkin = document.getElementById("checkin");
  const checkout = document.getElementById("checkout");
  checkin.min = localDate;
  checkout.min = localDate;

  checkin.addEventListener("change", () => {
    if (checkin.value) {
      const nextDay = new Date(`${checkin.value}T12:00:00`);
      nextDay.setDate(nextDay.getDate() + 1);
      const minCheckout = `${nextDay.getFullYear()}-${String(nextDay.getMonth()+1).padStart(2,"0")}-${String(nextDay.getDate()).padStart(2,"0")}`;
      checkout.min = minCheckout;
      if (!checkout.value || checkout.value <= checkin.value) checkout.value = minCheckout;
    }
  });

  document.getElementById("booking-form").addEventListener("submit", event => {
    event.preventDefault();
    if (!checkin.value || !checkout.value) {
      showToast("Please choose your check-in and check-out dates.");
      return;
    }
    if (checkout.value <= checkin.value) {
      showToast("Check-out must be after check-in.");
      checkout.focus();
      return;
    }
    const guests = document.getElementById("guests").value;
    const room = document.getElementById("room-type").value;
    const message = [
      "Hello Grand Palace Hotel, I would like to enquire about a booking.",
      `Check-in: ${checkin.value}`,
      `Check-out: ${checkout.value}`,
      `Guests: ${guests}`,
      `Room preference: ${room}`,
      "Please confirm availability and rates. Thank you."
    ].join("\n");
    openWhatsApp(message);
  });

  document.querySelectorAll(".book-room").forEach(button => {
    button.addEventListener("click", () => {
      document.getElementById("room-type").value =
        button.dataset.room === "Palace Suite" ? "Suite Room" : button.dataset.room;
      document.getElementById("booking").scrollIntoView({ behavior: "smooth" });
      showToast(`${button.dataset.room} selected. Choose dates to send your enquiry.`);
    });
  });

  const contactMessage = "Hello Grand Palace Hotel, I would like to know more about your rooms and rates.";
  ["contact-whatsapp", "floating-whatsapp"].forEach(id => {
    const link = document.getElementById(id);
    link?.addEventListener("click", event => {
      event.preventDefault();
      openWhatsApp(contactMessage);
    });
  });

  const lightbox = document.getElementById("lightbox");
  const lightboxImage = document.getElementById("lightbox-image");
  document.querySelectorAll(".gallery-item").forEach(item => {
    item.addEventListener("click", () => {
      lightboxImage.src = item.dataset.full;
      lightboxImage.alt = item.querySelector("img").alt;
      if (typeof lightbox.showModal === "function") lightbox.showModal();
      else window.open(item.dataset.full, "_blank", "noopener,noreferrer");
    });
  });
  document.getElementById("lightbox-close").addEventListener("click", () => lightbox.close());
  lightbox.addEventListener("click", event => {
    if (event.target === lightbox) lightbox.close();
  });

  document.getElementById("year").textContent = new Date().getFullYear();
});
