# Grand Palace Hotel Website

A responsive luxury hotel website made with plain HTML, CSS, and JavaScript.

## Files
- `index.html` — page content and structure
- `styles.css` — responsive styling
- `script.js` — mobile navigation, booking enquiry, WhatsApp links, gallery lightbox
- `README.md` — setup notes

## Run locally
1. Extract the ZIP file.
2. Open the `grand_palace_hotel` folder.
3. Double-click `index.html` to open it in a modern browser.
4. Internet is needed for the hosted photos and Google Fonts. The page structure and styling are local.

You can also open the folder in VS Code and use the Live Server extension.

## Before publishing — required customization
1. Open `script.js` and replace:
   `const WHATSAPP_NUMBER = "910000000000";`
   with the hotel's real WhatsApp number, including country code and digits only.
2. In `index.html`, replace `[Add hotel address]`, `[Add hotel phone number]`, `[Add hotel email address]`, and the example email address.
3. Replace sample photos with approved photos of the actual property.
4. Confirm actual room types, room amenities, and hotel facilities. Sample copy is provided.
5. Add a privacy policy and terms relevant to your business if needed.

## Booking behaviour and limitations
The form validates the selected dates and opens WhatsApp with a pre-filled booking enquiry. It does **not** store a reservation, check real-time room availability, charge a payment method, or confirm a booking. Staff must respond to confirm availability and rates.

For real online booking, add a secure backend/database or connect a reputable booking engine. Do not collect card details through WhatsApp or this static page.

## Deployment
Upload `index.html`, `styles.css`, and `script.js` to the public web root of a hosting account. Keep all three files in the same directory unless you update the paths.
